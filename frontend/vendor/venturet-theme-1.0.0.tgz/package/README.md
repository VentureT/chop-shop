# @venturet/theme

Shared antd theme provider + **live theme generator** for VentureT pitch-brief
apps. Wrap your app once; get instant, persisted theming of primary/secondary
color, border radius, font size, shadows, density, and light/dark — adjustable
live from a faint gear dialog, and exportable back into the app's committed
`src/theme.ts` baseline.

Implemented once here; every pitch-brief app depends on it as a git dependency.

## Install (git dependency)

```jsonc
"dependencies": {
  "@venturet/theme": "git+https://github.com/VentureT/theme.git#semver:^1.0.0"
}
```

Peers: `react`, `react-dom`, `antd` (v5).

## Use

```tsx
import { ThemeProvider, ThemeSettings } from '@venturet/theme';
import { baseTheme } from './theme'; // your committed default (Partial<ThemeTokens>)

export function Root() {
  return (
    <ThemeProvider defaultTokens={baseTheme}>
      <ThemeSettings />   {/* faint gear; opens the live generator */}
      <App />
    </ThemeProvider>
  );
}
```

`ThemeProvider` renders antd's `ConfigProvider` (with `cssVar` on) + `App`, so
**all antd components — including other VentureT packages like
`@venturet/docs-viewer` — re-theme live** as the tokens change. Tweaks persist to
`localStorage`; **Copy config** puts the current tokens on the clipboard to paste
into `src/theme.ts` as the new default.

## API

- `ThemeProvider({ defaultTokens?, storageKey?, children })`
- `ThemeSettings({ triggerLabel? })` — the gear + drawer generator
- `useTheme()` → `{ tokens, setTokens, reset }`
- `makeThemeConfig(tokens)` → antd `ThemeConfig`
- `DEFAULT_TOKENS`, `SHADOW_VALUES`, types `ThemeTokens` / `ThemeMode` / `Density` / `ShadowPreset`

## Tokens

`colorPrimary`, `colorSecondary`, `borderRadius`, `fontSize`, `shadow`
(`none|subtle|elevated`), `density` (`comfortable|compact`), `mode`
(`light|dark`). The secondary color is also exposed as the CSS var
`--app-color-secondary` for app-specific use.

## Develop / release

```bash
npm install
npm run build        # tsc -> dist/ (committed for git installs)
git tag v1.0.1 && git push --tags
```
