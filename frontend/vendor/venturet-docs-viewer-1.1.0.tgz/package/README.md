# @venturet/docs-viewer

Reusable, in-app documentation viewer for VentureT pitch-brief apps. Renders a
`docs/` directory of (countless, nested) markdown files as a browsable
folder/file tree + markdown reader, behind a deliberately faint corner trigger.

Implemented once here; every pitch-brief app depends on it as a git dependency
rather than copying the component.

## Install (git dependency)

```jsonc
// package.json
"dependencies": {
  "@venturet/docs-viewer": "git+https://github.com/VentureT/docs-viewer.git#semver:^1.0.0"
}
```

Peers: `react`, `react-dom`, `antd` (v5). `react-markdown` + `remark-gfm` come
bundled as dependencies.

## Use

The consuming app discovers its own markdown with Vite's `import.meta.glob` and
passes the result in. The component does the rest (tree, rendering, trigger,
modal).

```tsx
import { DocsViewer } from '@venturet/docs-viewer';

// Glob ALL markdown under the project's docs/ (any depth). The pattern is
// relative to this file; adjust the `../` depth to reach the project-root docs/.
const files = import.meta.glob('../../docs/**/*.md', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>;

export default function App() {
  return <DocsViewer files={files} />;
}
```

Vite must be allowed to read files above the frontend root:

```ts
// vite.config.ts
server: { fs: { allow: ['..'] } }
```

Drop any `.md` file (in any subfolder) into `docs/` and it appears in the tree —
no registration. The viewer is read-only (no add/manage of files or folders).

## Props

| Prop | Type | Default | Notes |
|---|---|---|---|
| `files` | `Record<string,string>` | — | path → raw markdown (from `import.meta.glob`) |
| `triggerLabel` | `string` | `"···"` | the faint corner trigger |
| `title` | `string` | `"Documentation"` | modal title |

## Develop / release

```bash
npm install
npm run build        # tsc -> dist/ (committed, so git installs work)
# bump version, commit dist, then:
git tag v1.0.1 && git push --tags
```

`dist/` is intentionally committed so the package installs directly from git
without a build step on the consumer side.
